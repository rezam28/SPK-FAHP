

<?php $__env->startSection('title',"Daerah"); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="table-hasil">
    <div class="panel">
          <div class="panel-header">
            <h3 class="title-center">Macam - Macam Daerah</h3>
          </div>
            <div class="row">
              <div class="col-12">
              <table id="table" class="table table-bordered table-striped">
                  <?php echo csrf_field(); ?>
                  <thead>
                      <tr>
                          <th scope="col">No</th>
                          <th scope="col">Nama Daerah/Kecamatan</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php $__currentLoopData = $daerah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td><?php echo e($loop->iteration); ?></td>
                              <td><?php echo e($item->nama_daerah); ?></td>
                          </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  </table>
              </div>
          </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zam\Downloads\laravel\tugasakhir\resources\views/daerah.blade.php ENDPATH**/ ?>