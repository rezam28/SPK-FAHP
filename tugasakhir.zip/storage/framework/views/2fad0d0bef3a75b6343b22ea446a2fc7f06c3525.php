

<?php $__env->startSection('title',"Hasil Ranking"); ?>

<?php $__env->startSection('css'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="hasil">
    <div class="table-hasil table-striped">
        <h3>Hasil Perhitungan Pemilihan Jenis Tanaman Pangan Terbaik Di Kecamatan <?php echo e($data['daerah'][0]); ?></h3>
        <hr style="width:1150px;">

        
        <div class="panel panel-default">
            <div class="panel-title">
                <strong>Perhitungan Kriteria </strong>
            </div>
            <div style="overflow-x: auto">
                <div class="panel-heading table-bordered table-stripes">
                    <strong>Matrik perbandingan Kriteria AHP </strong>
                </div>
                <table class="table table-bordered table-stripes table-responsive-md" id="table_skala_ahp">
                    <thead>
                        <tr>
                            <th></th>
                            <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e($item['kode']); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kolom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td><?php echo e($kolom['kode']); ?> - <?php echo e($kolom->nama_kriteria); ?></td>
                                <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $baris): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td>
                                    <?php $__currentLoopData = $perkriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($baris->kode == $value->kriteria2->kode && $kolom->kode == $value->kriteria1->kode): ?>
                                            <?php echo e($value->nilai); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            
            
            <div style="overflow-x: auto">
                <div class="panel-heading">
                    <strong>Matrik perbandingan Kriteria Fuzzy AHP </strong>
                </div>
                <table class="table table-bordered table-stripes" id="table_fuzzy_ahp">
                    <thead>
                        <tr>
                            <th></th>
                            <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th colspan="3"><?php echo e($item['kode']); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <tr></tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td></td>
                            <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th>L</th>
                                <th>M</th>
                                <th>U</th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kolom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($kolom['kode']); ?> - <?php echo e($kolom->nama_kriteria); ?></td>
                                <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $baris): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td>
                                        <?php $__currentLoopData = $perkriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($baris->kode == $value->kriteria2->kode && $kolom->kode == $value->kriteria1->kode): ?>
                                                <?php if($value->nilai == 1 || 1/$value->nilai == 1): ?>
                                                    1
                                                <?php elseif($value->nilai == 2): ?>
                                                    <?php echo e(1/2); ?>

                                                <?php elseif($value->nilai == 1/2): ?>
                                                    <?php echo e(round(2/3,3)); ?>

                                                <?php elseif($value->nilai == 3): ?>
                                                    <?php echo e(1); ?>

                                                <?php elseif($value->nilai == round(1/3,3)): ?>
                                                    <?php echo e(1/2); ?>

                                                <?php elseif($value->nilai == 4): ?>
                                                    <?php echo e(3/2); ?>

                                                <?php elseif($value->nilai == 1/4): ?>
                                                    <?php echo e(2/5); ?>

                                                <?php elseif($value->nilai == 4): ?>
                                                    <?php echo e(1); ?>

                                                <?php elseif($value->nilai == 1/4): ?>
                                                    <?php echo e(1/2); ?>

                                                <?php elseif($value->nilai == 5): ?>
                                                    <?php echo e(2); ?>

                                                <?php elseif($value->nilai == 1/5): ?>
                                                    <?php echo e(round(1/3,3)); ?>

                                                <?php elseif($value->nilai == 6): ?>
                                                    <?php echo e(5/2); ?>

                                                <?php elseif($value->nilai == round(1/6,3)): ?>
                                                    <?php echo e(round(2/7,3)); ?>

                                                <?php endif; ?>    
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <?php $__currentLoopData = $perkriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($baris->kode == $value->kriteria2->kode && $kolom->kode == $value->kriteria1->kode): ?>
                                                <?php if($value->nilai == 1 || 1/$value->nilai == 1): ?>
                                                    1
                                                <?php elseif($value->nilai == 2): ?>
                                                    <?php echo e(1); ?>

                                                <?php elseif($value->nilai == 1/2): ?>
                                                    <?php echo e(1); ?>

                                                <?php elseif($value->nilai == 3): ?>
                                                    <?php echo e(3/2); ?>

                                                <?php elseif($value->nilai == round(1/3,3)): ?>
                                                    <?php echo e(round(2/3,3)); ?>

                                                <?php elseif($value->nilai == 4): ?>
                                                    <?php echo e(2); ?>

                                                <?php elseif($value->nilai == 1/4): ?>
                                                    <?php echo e(1/2); ?>

                                                <?php elseif($value->nilai == 4): ?>
                                                    <?php echo e(2); ?>

                                                <?php elseif($value->nilai == 1/4): ?>
                                                    <?php echo e(1/2); ?>

                                                <?php elseif($value->nilai == 5): ?>
                                                    <?php echo e(5/2); ?>

                                                <?php elseif($value->nilai == 1/5): ?>
                                                    <?php echo e(2/5); ?>

                                                <?php elseif($value->nilai == 6): ?>
                                                    <?php echo e(3); ?>

                                                <?php elseif($value->nilai == round(1/6,3)): ?>
                                                    <?php echo e(round(1/3,3)); ?>

                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <?php $__currentLoopData = $perkriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($baris->kode == $value->kriteria2->kode && $kolom->kode == $value->kriteria1->kode): ?>
                                                <?php if($value->nilai == 1 || 1/$value->nilai == 1): ?>
                                                    1
                                                <?php elseif($value->nilai == 2): ?>
                                                    <?php echo e(3/2); ?>

                                                <?php elseif($value->nilai == 1/2): ?>
                                                    <?php echo e(2); ?>

                                                <?php elseif($value->nilai == 3): ?>
                                                    <?php echo e(2); ?>

                                                <?php elseif($value->nilai == round(1/3,3)): ?>
                                                    <?php echo e(1); ?>

                                                <?php elseif($value->nilai == 4): ?>
                                                    <?php echo e(5/2); ?>

                                                <?php elseif($value->nilai == 1/4): ?>
                                                    <?php echo e(round(2/3,3)); ?>

                                                <?php elseif($value->nilai == 5): ?>
                                                    <?php echo e(3); ?>

                                                <?php elseif($value->nilai == 1/5): ?>
                                                    <?php echo e(1/2); ?>

                                                <?php elseif($value->nilai == 6): ?>
                                                    <?php echo e(7/2); ?>

                                                <?php elseif($value->nilai == round(1/6,3)): ?>
                                                    <?php echo e(2/5); ?>

                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            

            <div class="table-responsive-md col-12">
                <div class="panel-heading table-bordered table-stripes">
                    <strong>Nilai Sintetis</strong>
                </div>
                <table class="table table-bordered table-stripes table-responsive-md" id="table_si">
                    <thead>
                        <tr>
                            <th></th>
                            <th colspan="3">Jumlah baris</th>
                            <th colspan="3">Nilai SI</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td></td>
                            <?php for($i = 0; $i < 2; $i++): ?>
                            <th>L</th>
                            <th>M</th>
                            <th>U</th>
                            <?php endfor; ?>
                        </tr>
                        <?php $__currentLoopData = $data['kodekri']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($value); ?></td>
                                <td><?php echo e(round($data['jumlahnilail'][$key],3)); ?></td>
                                <td><?php echo e(round($data['jumlahnilaim'][$key],3)); ?></td>
                                <td><?php echo e(round($data['jumlahnilaiu'][$key],3)); ?></td>
                                <td><?php echo e(round($data['nilaisil'][$key],3)); ?></td>
                                <td><?php echo e(round($data['nilaisim'][$key],3)); ?></td>
                                <td><?php echo e(round($data['nilaisiu'][$key],3)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>Jumlah</td>
                            <td><?php echo e(round($data['sumnilail'],3)); ?></td>
                            <td><?php echo e(round($data['sumnilaim'],3)); ?></td>
                            <td><?php echo e(round($data['sumnilaiu'],3)); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            

            <div class="table-responsive-md col-12">
                <div class="panel-heading table-bordered table-stripes">
                    <strong>Nilai Vektor Dan Defuzzifikasi</strong>
                </div>
                <?php $__currentLoopData = $data['kodekri']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel-heading table-bordered table-stripes">
                    <strong><?php echo e($isi); ?> - <?php echo e($data['namakri'][$no]); ?></strong>
                </div>
                <table class="table table-bordered table-stripes table-responsive-md" id="table_defuzzifikasi">
                    <thead>
                        <tr>
                            <th></th>
                            <th>Nilai Defuzzifikasi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data['defuzzy'][$no]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php if($no != $key): ?>
                                    <td><?php echo e($isi); ?> > <?php echo e($data['kodekri'][$key]); ?></td>
                                    <td><?php echo e(round($value,3)); ?></td>
                                <?php endif; ?>
                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>Min / Vektor</td>
                            <td><?php echo e(round($data['vektor'][$no],3)); ?></td>
                        </tr>
                    </tbody>
                </table>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="table-responsive-md col-12">
                <div class="panel-heading table-bordered table-stripes">
                    <strong>Normalisasi Bobot Vektor</strong>
                </div>
                <table class="table table-bordered table-stripes table-responsive-md" id="table_si">
                    <thead>
                        <tr>
                            <th>Kriteria</th>
                            <th>W / Vektor</th>
                            <th>Wlokal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data['namakri']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($data['kodekri'][$no]); ?> - <?php echo e($item); ?></td>
                                <td><?php echo e(round($data['vektor'][$no],3)); ?></td>
                                <td><?php echo e(round($data['bobotkri'][$no],3)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        

        <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <div class="panel panel-default" id="alternatif_panel">
                <div class="panel-title">
                    <a href="javascript:void(0)" id="<?php echo e($item->kode); ?>" value="<?php echo e($item->nama_kriteria); ?>">Perhitungan Alternatif Terhadap Kriteria <?php echo e($item->nama_kriteria); ?></a>
                    
                </div>
                
                <div class="alternatif table-responsive-md col-12" id="alternatif_ahp_<?php echo e($item->kode); ?>" style="display: none">
                    <div class="panel-heading table-bordered table-stripes">
                        <strong>Matrik perbandingan Alternatif Terhadap Kriteria <?php echo e($item->nama_kriteria); ?> AHP </strong>
                    </div>
                    <table class="table table-bordered table-stripes table-responsive-md" id="table_skala_ahp">
                        <thead>
                            <tr>
                                <th></th>
                                <?php $__currentLoopData = $data['kodealter']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th><?php echo e($value); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['selected']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nk => $kolom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($data['kodealter'][$nk]); ?> - <?php echo e($data['namaalter'][$nk]); ?></td>
                                    <?php $__currentLoopData = $data['selected']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nb => $baris): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td>
                                        <?php $__currentLoopData = $peralternatif[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($data['kodealter'][$nb] == $value->alternatif2->kode && $data['kodealter'][$nk] == $value->alternatif1->kode): ?>
                                                <?php echo e($value->nilai); ?>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                
                <div class="table-responsive-md col-12" id="alternatif_fahap_<?php echo e($item->kode); ?>" style="display: none">
                    <div class="panel-heading">
                        <strong>Matrik perbandingan Alternatif Terhadap Kriteria <?php echo e($item->nama_kriteria); ?> Fuzzy AHP </strong>
                    </div>
                    <table class="table table-bordered table-stripes table-responsive-md" id="table_fuzzy_ahp" style="overflow-x: auto">
                        <thead>
                            <tr>
                                <th></th>
                                <?php $__currentLoopData = $data['kodealter']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th colspan="3"><?php echo e($value); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr></tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td></td>
                                <?php $__currentLoopData = $data['kodealter']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td>L</td>
                                    <td>M</td>
                                    <td>U</td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <?php $__currentLoopData = $data['selected']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nk => $kolom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($data['kodealter'][$nk]); ?> - <?php echo e($data['namaalter'][$nk]); ?></td>
                                    <?php $__currentLoopData = $data['selected']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nb => $baris): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td>
                                        <?php $__currentLoopData = $peralternatif[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($data['kodealter'][$nb] == $value->alternatif2->kode && $data['kodealter'][$nk] == $value->alternatif1->kode): ?>
                                                <?php if($value->nilai == 1 || 1/$value->nilai == 1): ?>
                                                    1
                                                <?php elseif($value->nilai == 2): ?>
                                                    <?php echo e(1/2); ?>

                                                <?php elseif($value->nilai == 1/2): ?>
                                                    <?php echo e(round(2/3,3)); ?>

                                                <?php elseif($value->nilai == 3): ?>
                                                    <?php echo e(1); ?>

                                                <?php elseif($value->nilai == round(1/3,3)): ?>
                                                    <?php echo e(1/2); ?>

                                                <?php elseif($value->nilai == 4): ?>
                                                    <?php echo e(3/2); ?>

                                                <?php elseif($value->nilai == 1/4): ?>
                                                    <?php echo e(2/5); ?>

                                                <?php elseif($value->nilai == 4): ?>
                                                    <?php echo e(1); ?>

                                                <?php elseif($value->nilai == 1/4): ?>
                                                    <?php echo e(1/2); ?>

                                                <?php elseif($value->nilai == 5): ?>
                                                    <?php echo e(2); ?>

                                                <?php elseif($value->nilai == 1/5): ?>
                                                    <?php echo e(round(1/3,3)); ?>

                                                <?php elseif($value->nilai == 6): ?>
                                                    <?php echo e(5/2); ?>

                                                <?php elseif($value->nilai == round(1/6,3)): ?>
                                                    <?php echo e(round(2/7,3)); ?>

                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <?php $__currentLoopData = $peralternatif[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($data['kodealter'][$nb] == $value->alternatif2->kode && $data['kodealter'][$nk] == $value->alternatif1->kode): ?>
                                                <?php if($value->nilai == 1 || 1/$value->nilai == 1): ?>
                                                    1
                                                <?php elseif($value->nilai == 2): ?>
                                                    <?php echo e(1); ?>

                                                <?php elseif($value->nilai == 1/2): ?>
                                                    <?php echo e(1); ?>

                                                <?php elseif($value->nilai == 3): ?>
                                                    <?php echo e(3/2); ?>

                                                <?php elseif($value->nilai == round(1/3,3)): ?>
                                                    <?php echo e(round(2/3,3)); ?>

                                                <?php elseif($value->nilai == 4): ?>
                                                    <?php echo e(2); ?>

                                                <?php elseif($value->nilai == 1/4): ?>
                                                    <?php echo e(1/2); ?>

                                                <?php elseif($value->nilai == 4): ?>
                                                    <?php echo e(2); ?>

                                                <?php elseif($value->nilai == 1/4): ?>
                                                    <?php echo e(1/2); ?>

                                                <?php elseif($value->nilai == 5): ?>
                                                    <?php echo e(5/2); ?>

                                                <?php elseif($value->nilai == 1/5): ?>
                                                    <?php echo e(2/5); ?>

                                                <?php elseif($value->nilai == 6): ?>
                                                    <?php echo e(3); ?>

                                                <?php elseif($value->nilai == round(1/6,3)): ?>
                                                    <?php echo e(round(1/3,3)); ?>

                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <?php $__currentLoopData = $peralternatif[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($data['kodealter'][$nb] == $value->alternatif2->kode && $data['kodealter'][$nk] == $value->alternatif1->kode): ?>
                                                <?php if($value->nilai == 1 || 1/$value->nilai == 1): ?>
                                                    1
                                                <?php elseif($value->nilai == 2): ?>
                                                    <?php echo e(3/2); ?>

                                                <?php elseif($value->nilai == 1/2): ?>
                                                    <?php echo e(2); ?>

                                                <?php elseif($value->nilai == 3): ?>
                                                    <?php echo e(2); ?>

                                                <?php elseif($value->nilai == round(1/3,3)): ?>
                                                    <?php echo e(1); ?>

                                                <?php elseif($value->nilai == 4): ?>
                                                    <?php echo e(5/2); ?>

                                                <?php elseif($value->nilai == 1/4): ?>
                                                    <?php echo e(round(2/3,3)); ?>

                                                <?php elseif($value->nilai == 5): ?>
                                                    <?php echo e(3); ?>

                                                <?php elseif($value->nilai == 1/5): ?>
                                                    <?php echo e(1/2); ?>

                                                <?php elseif($value->nilai == 6): ?>
                                                    <?php echo e(7/2); ?>

                                                <?php elseif($value->nilai == round(1/6,3)): ?>
                                                    <?php echo e(2/5); ?>

                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                
                <div class="table-responsive-md col-12" id="alternatif_si_<?php echo e($item->kode); ?>" style="display: none">
                    <div class="panel-heading table-bordered table-stripes">
                        <strong>Nilai Sintetis</strong>
                    </div>
                    <table class="table table-bordered table-stripes table-responsive-md" id="table_si">
                        <thead>
                            <tr>
                                <th></th>
                                <th colspan="3">Jumlah baris</th>
                                <th colspan="3">Nilai SI</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td></td>
                                <?php for($i = 0; $i < 2; $i++): ?>
                                <th>L</th>
                                <th>M</th>
                                <th>U</th>
                                <?php endfor; ?>
                            </tr>
                            <?php $__currentLoopData = $data['kodealter']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($value); ?></td>
                                    <td><?php echo e(round($data['jmlbarisalterl'][$key][$no],3)); ?></td>
                                    <td><?php echo e(round($data['jmlbarisalterm'][$key][$no],3)); ?></td>
                                    <td><?php echo e(round($data['jmlbarisalteru'][$key][$no],3)); ?></td>
                                    <td><?php echo e(round($data['nilaialtersil'][$key][$no],3)); ?></td>
                                    <td><?php echo e(round($data['nilaialtersim'][$key][$no],3)); ?></td>
                                    <td><?php echo e(round($data['nilaialtersiu'][$key][$no],3)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>Jumlah</td>
                                <td><?php echo e(round($data['sumjmlalterl'][$key],3)); ?></td>
                                <td><?php echo e(round($data['sumjmlalterm'][$key],3)); ?></td>
                                <td><?php echo e(round($data['sumjmlalteru'][$key],3)); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                
                <div class="table-responsive-md col-12" id="alternatif_vektor_<?php echo e($item->kode); ?>" style="display: none">
                    <div class="panel-heading table-bordered table-stripes">
                        <strong>Nilai Vektor Dan Defuzzifikasi Alternatif</strong>
                    </div>
                    <?php $__currentLoopData = $data['kodealter']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="panel-heading table-bordered table-stripes">
                        <strong><?php echo e($isi); ?> - <?php echo e($data['namaalter'][$no]); ?></strong>
                    </div>
                    <table class="table table-bordered table-stripes table-responsive-md" id="table_defuzzifikasi">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Nilai Defuzzifikasi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['alterdefuzzy'][$key][$no]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php if($no != $num): ?>
                                        <td><?php echo e($isi); ?> > <?php echo e($data['kodealter'][$num]); ?></td>
                                        <td><?php echo e(round($value,3)); ?></td>
                                    <?php endif; ?>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>Min / Vektor</td>
                                <td><?php echo e(round($data['vektoralter'][$key][$no],3)); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                
                <div class="table-responsive-md col-12" id="alternatif_normalisasi_<?php echo e($item->kode); ?>" style="display: none">
                    <div class="panel-heading table-bordered table-stripes">
                        <strong>Normalisasi Bobot Vektor Alternatif</strong>
                    </div>
                    <table class="table table-bordered table-stripes table-responsive-md" id="table_si">
                        <thead>
                            <tr>
                                <th>Alternatif</th>
                                <th>W / Vektor</th>
                                <th>Wlokal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['namaalter']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($data['kodealter'][$no]); ?> - <?php echo e($item); ?></td>
                                    <td><?php echo e(round($data['vektoralter'][$key][$no],3)); ?></td>
                                    <td><?php echo e(round($data['bobotalter'][$key][$no],3)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <div class="panel" id="hasil-pembobotan">

            
            <div class="table-responsive-md col-12">
                <div class="panel-heading table-bordered table-stripes">
                    <strong>Hasil Pembobotan</strong>
                </div>
                <table class="table table-bordered table-stripes table-responsive-md" id="table_hasil_pembobotan">
                    <thead>
                        <tr>
                            <th>kriteria</th>
                            <th></th>
                            <th colspan="<?php echo e(count($data['selected'])); ?>">Skor Alternatif yang Berhubungan Dengan Kriteria Terkait</th>
                        </tr>
                        <tr>
                            <th></th>
                            <th>W</th>
                            <?php $__currentLoopData = $data['selected']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e($data['kodealter'][$key]); ?> - <?php echo e($data['namaalter'][$key]); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data['kodekri']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item); ?> - <?php echo e($data['namakri'][$key]); ?></td>
                                <td><?php echo e(round($data['bobotkri'][$key],3)); ?></td>
                                <?php $__currentLoopData = $data['bobotalter'][$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                
                                    <td><?php echo e(round($data['bobotalter'][$key][$num],3)); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="2">Total</td>
                            <?php $__currentLoopData = $data['hasil']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e(round($item,3)); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </tbody>
                </table>
            </div>

            
            <div id="hasil-ranking">
                <h3>Hasil Perankingan</h3>
            </div>
            <table class="table table-striped">
                <thead>
                    <tr>
                    <th scope="col">Ranking</th>
                    <th scope="col">Alternatif</th>
                    <th scope="col">Bobot Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data['ranking']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <?php $__currentLoopData = $data['kodealter']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($key == $value): ?>
                                    <td><?php echo e($value); ?> - <?php echo e($data['namaalter'][$no]); ?></td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e(round($item,3)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"
        integrity="sha256-sPB0F50YUDK0otDnsfNHawYmA5M0pjjUf4TvRJkGFrI=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"
        integrity="sha256-sPB0F50YUDK0otDnsfNHawYmA5M0pjjUf4TvRJkGFrI=" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        $(document).ready(function () {
           
            $('html, body').animate({
                scrollTop: $("#hasil-ranking").offset().top
            }, 2000);
        });
        $('a').click(function () { 
            var id = $(this).attr("id");
            // console.log(id);
            $('#alternatif_ahp_'+ id).toggle(1000);
            $('#alternatif_fahap_' + id).toggle(1000);
            $('#alternatif_si_'+id).toggle(1000);
            $('#alternatif_vektor_'+id).toggle(1000);
            $('#alternatif_normalisasi_'+id).toggle(1000);            
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zam\Downloads\laravel\tugasakhir\resources\views/hasilranking.blade.php ENDPATH**/ ?>