@extends('layout.main')

@section('title',"Welcome")

@section('css')

@endsection

@section('container')
Welcome
@endsection

@section('javascript')

@endsection