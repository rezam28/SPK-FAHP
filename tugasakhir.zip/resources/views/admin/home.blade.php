@extends('admin.layouts.main')

@section('title',"Admin")

@section('css')

@endsection

@section('content')
<div>
    <h1>Halaman Admin</h1>
</div>
@endsection

@section('javascript')

@endsection